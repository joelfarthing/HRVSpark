//
//  HRVSpark_Watch_AppApp.swift
//  HRVSpark Watch App Watch App
//
//  Created by Joel Farthing on 2/22/26.
//

import SwiftUI

@main
struct HRVSpark_Watch_App_Watch_AppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
