import WidgetKit
import SwiftUI
import HealthKit

private let gaugeTimeframeColor = Color(red: 0.34, green: 0.72, blue: 1.0)

// MARK: - App Group Manager

// We use an App Group or UserDefaults to share data between the main App and the Widget.
// For now, since we haven't set up an App Group, the widget will fetch its own data directly.
// This is perfectly fine for a watchOS complication.

// MARK: - Entry

struct HRVEntry: TimelineEntry {
    let date: Date
    let latestReading: Int?
    let sparkline8h: [Double?]
    let hourlyAverages24h: [Double?]
    let rollingAvg1h: Int?
    let rollingAvg24h: Int?
    let dailyAverages7d: [Double?]
    let dailyAverages30d: [Double?]
}

// MARK: - Default Provider

struct Provider: TimelineProvider {
    // Keep a single manager instance alive for the widget extension process so
    // WCSession delegate callbacks can hydrate long-term payloads over time.
    private static let sharedDataManager = HRVDataManager()
    private var dataManager: HRVDataManager { Self.sharedDataManager }

    func placeholder(in context: Context) -> HRVEntry {
        HRVEntry(
            date: Date(),
            latestReading: 50,
            sparkline8h: [45, 48, 52, 50, 49, 53, 50],
            hourlyAverages24h: [48, 50, 49, 51, 52, 50],
            rollingAvg1h: 50,
            rollingAvg24h: 48,
            dailyAverages7d: [46, 48, 50, 49, 51, 48, 50],
            dailyAverages30d: [45, 47, 49, 48, 50, 49, 48]
        )
    }

    func getSnapshot(in context: Context, completion: @escaping (HRVEntry) -> ()) {
        let entry = HRVEntry(
            date: Date(),
            latestReading: 50,
            sparkline8h: [45, 48, 52, 50, 49, 53, 50],
            hourlyAverages24h: [48, 50, 49, 51, 52, 50],
            rollingAvg1h: 50,
            rollingAvg24h: 48,
            dailyAverages7d: [46, 48, 50, 49, 51, 48, 50],
            dailyAverages30d: [45, 47, 49, 48, 50, 49, 48]
        )
        completion(entry)
    }

    func getTimeline(in context: Context, completion: @escaping (Timeline<Entry>) -> ()) {
        dataManager.fetchAllComplicationData { latestReading, sparkline8h, hourlyAverages24h, rollingAvg1h, rollingAvg24h, dailyAverages7d, dailyAverages30d in
            let entry = HRVEntry(
                date: Date(),
                latestReading: latestReading,
                sparkline8h: sparkline8h,
                hourlyAverages24h: hourlyAverages24h,
                rollingAvg1h: rollingAvg1h,
                rollingAvg24h: rollingAvg24h,
                dailyAverages7d: dailyAverages7d,
                dailyAverages30d: dailyAverages30d
            )
            
            // Retry faster when 30D still appears sparse so companion payload can take over sooner.
            let visible30dCount = dailyAverages30d.compactMap { $0 }.count
            let refreshMinutes = visible30dCount < 20 ? 3 : 15
            let nextUpdateDate = Calendar.current.date(byAdding: .minute, value: refreshMinutes, to: Date())!
            let timeline = Timeline(entries: [entry], policy: .after(nextUpdateDate))

            completion(timeline)
        }
    }
}

// MARK: - Generic Specific Complication Family Views
// We parameterize these so we can reuse them across all 10 complications

struct GenericCircularComplicationView: View {
    var currentValue: Int?
    var dataArray: [Double?]
    var timeframeLabel: String
    
    var body: some View {
        let current = Double(currentValue ?? 0)
        let validData = dataArray.compactMap { $0 }
        let minVal = validData.min() ?? 0
        let calculatedMax = validData.max() ?? 100
        let maxVal = max(calculatedMax, current) + 1
        
        ZStack(alignment: .bottom) {
            Gauge(value: current, in: minVal...maxVal) {
                Text(" ")
            } currentValueLabel: {
                if let val = currentValue {
                    Text("\(val)")
                        .font(.system(.title3, design: .monospaced, weight: .bold))
                } else {
                    Text("--")
                        .font(.system(.title3, design: .monospaced, weight: .bold))
                }
            } minimumValueLabel: {
                Text("\(Int(round(minVal)))")
                    .font(.system(size: 9, weight: .bold, design: .monospaced))
                    .foregroundColor(.gray)
            } maximumValueLabel: {
                Text("\(Int(round(maxVal - 1)))")
                    .font(.system(size: 9, weight: .bold, design: .monospaced))
                    .foregroundColor(.gray)
            }
            .gaugeStyle(.accessoryCircular)
            .tint(.white)
            
            Text(timeframeLabel)
                .font(.system(size: 9, weight: .bold, design: .monospaced))
                .foregroundColor(gaugeTimeframeColor)
                .padding(.bottom, 1)
        }
    }
}

struct GenericCornerComplicationView: View {
    var currentValue: Int?
    var dataArray: [Double?]
    var timeframeLabel: String
    
    var body: some View {
        let current = Double(currentValue ?? 0)
        let validData = dataArray.compactMap { $0 }
        let minVal = validData.min() ?? 0
        let calculatedMax = validData.max() ?? 100
        let maxVal = max(calculatedMax, current) + 1
        
        Gauge(value: current, in: minVal...maxVal) {
            Text(" ")
        } currentValueLabel: {
            Image(systemName: "circle.fill")
                .font(.system(size: 7, weight: .bold))
        } minimumValueLabel: {
            Text(timeframeLabel)
                .font(.system(size: 8, weight: .bold, design: .monospaced))
                .foregroundColor(gaugeTimeframeColor)
        } maximumValueLabel: {
            Text(" ")
                .font(.system(size: 8, weight: .bold, design: .monospaced))
                .foregroundColor(.clear)
        }
        .gaugeStyle(.accessoryCircular)
        .tint(.white)
        .widgetLabel {
            if let val = currentValue {
                Text("\(val)")
                    .font(.system(size: 11, weight: .bold, design: .monospaced))
            } else {
                Text("--")
                    .font(.system(size: 11, weight: .bold, design: .monospaced))
            }
        }
    }
}

struct GenericRectangularComplicationView: View {
    var currentValue: Int?
    var dataArray: [Double?]
    var timeframeLabel: String
    var maxSolidGap: Int = 1
    
    var body: some View {
        HStack(spacing: 8) {
            // Left Side: Sparkline Graph
            SparklineView(data: dataArray, maxContiguousGap: maxSolidGap)
                .frame(maxWidth: .infinity, maxHeight: .infinity)
            
            // Right Side: Text Data
            VStack(alignment: .leading, spacing: 2) {
                HStack(spacing: 2) {
                    Image(systemName: "triangle.fill")
                        .font(.system(size: 8, weight: .bold))
                        .rotationEffect(.degrees(-90))
                    Text(timeframeLabel)
                        .font(.system(size: 9, weight: .bold))
                }
                .foregroundColor(Color.white.opacity(0.92))
                
                Text("HRV")
                    .font(.system(size: 10, weight: .bold))
                    .foregroundColor(Color.white.opacity(0.72))
                
                if let val = currentValue {
                    HStack(alignment: .lastTextBaseline, spacing: 0) {
                        Text("\(val)")
                            .font(.system(.headline, design: .monospaced, weight: .bold))
                        Text("ms")
                            .font(.system(size: 9, design: .monospaced))
                            .foregroundColor(.gray)
                    }
                } else {
                    Text("--")
                        .font(.system(.headline, design: .monospaced, weight: .bold))
                }
            }
            .layoutPriority(1) // Ensure text doesn't get squished by the graph
        }
    }
}

// MARK: - 1. FREE TIER COMPLICATIONS

struct FreeSparklineComplication: Widget {
    let kind: String = "FreeSparklineComplication"
    var body: some WidgetConfiguration {
        StaticConfiguration(kind: kind, provider: Provider()) { entry in
            GenericRectangularComplicationView(currentValue: entry.latestReading, dataArray: entry.sparkline8h, timeframeLabel: "8H", maxSolidGap: 12)
                .containerBackground(.clear, for: .widget)
        }
        .configurationDisplayName("8H Raw Sparkline")
        .description("Your last 8 hours of raw HRV readings + most recent reading.")
        .supportedFamilies([.accessoryRectangular])
    }
}

struct FreeGaugeComplication: Widget {
    let kind: String = "FreeGaugeComplication"
    var body: some WidgetConfiguration {
        StaticConfiguration(kind: kind, provider: Provider()) { entry in
            GenericCircularComplicationView(currentValue: entry.latestReading, dataArray: entry.sparkline8h, timeframeLabel: "8H")
                .containerBackground(.clear, for: .widget)
        }
        .configurationDisplayName("8H Range Gauge")
        .description("Your 8-hour min/max range + most recent reading.")
        .supportedFamilies([.accessoryCircular])
    }
}

struct FreeCornerComplication: Widget {
    let kind: String = "FreeCornerComplication"
    var body: some WidgetConfiguration {
        StaticConfiguration(kind: kind, provider: Provider()) { entry in
            GenericCornerComplicationView(currentValue: entry.latestReading, dataArray: entry.sparkline8h, timeframeLabel: "8H")
                .containerBackground(.clear, for: .widget)
        }
        .configurationDisplayName("Most Recent HRV")
        .description("Your most recent reading with 8-hour context.")
        .supportedFamilies([.accessoryCorner])
    }
}

// MARK: - 2. PRO TIER (24H / DAILY)

struct ProHourlyComplication: Widget {
    let kind: String = "ProHourlyComplication"
    var body: some WidgetConfiguration {
        StaticConfiguration(kind: kind, provider: Provider()) { entry in
            GenericRectangularComplicationView(currentValue: entry.rollingAvg1h, dataArray: entry.hourlyAverages24h, timeframeLabel: "24H")
                .containerBackground(.clear, for: .widget)
        }
        .configurationDisplayName("24H Averages + 1H Avg")
        .description("[PRO] 24-hour hourly averages + 1-hour rolling average.")
        .supportedFamilies([.accessoryRectangular])
    }
}

struct ProHourlyGaugeComplication: Widget {
    let kind: String = "ProHourlyGaugeComplication"
    var body: some WidgetConfiguration {
        StaticConfiguration(kind: kind, provider: Provider()) { entry in
            GenericCircularComplicationView(currentValue: entry.rollingAvg1h, dataArray: entry.hourlyAverages24h, timeframeLabel: "24H")
                .containerBackground(.clear, for: .widget)
        }
        .configurationDisplayName("24H Gauge + 1H Avg")
        .description("[PRO] 24-hour min/max range + 1-hour rolling average.")
        .supportedFamilies([.accessoryCircular])
    }
}

struct ProDailyBaselineComplication: Widget {
    let kind: String = "ProDailyBaselineComplication"
    var body: some WidgetConfiguration {
        StaticConfiguration(kind: kind, provider: Provider()) { entry in
            GenericRectangularComplicationView(currentValue: entry.rollingAvg24h, dataArray: entry.hourlyAverages24h, timeframeLabel: "24H")
                .containerBackground(.clear, for: .widget)
        }
        .configurationDisplayName("24H Averages (Daily Baseline)")
        .description("[PRO] 24-hour hourly averages + 24-hour rolling average.")
        .supportedFamilies([.accessoryRectangular])
    }
}

// MARK: - 3. PRO TIER (WEEKLY / MONTHLY)

struct Pro7DayComplication: Widget {
    let kind: String = "Pro7DayComplication"
    var body: some WidgetConfiguration {
        StaticConfiguration(kind: kind, provider: Provider()) { entry in
            GenericRectangularComplicationView(currentValue: entry.rollingAvg24h, dataArray: entry.dailyAverages7d, timeframeLabel: "7D")
                .containerBackground(.clear, for: .widget)
        }
        .configurationDisplayName("7-Day Averages")
        .description("[PRO] 7-day daily averages + 24-hour rolling average.")
        .supportedFamilies([.accessoryRectangular])
    }
}

struct Pro7DayGaugeComplication: Widget {
    let kind: String = "Pro7DayGaugeComplication"
    var body: some WidgetConfiguration {
        StaticConfiguration(kind: kind, provider: Provider()) { entry in
            GenericCircularComplicationView(currentValue: entry.rollingAvg24h, dataArray: entry.dailyAverages7d, timeframeLabel: "7D")
                .containerBackground(.clear, for: .widget)
        }
        .configurationDisplayName("7-Day Gauge")
        .description("[PRO] 7-day min/max range + 24-hour rolling average.")
        .supportedFamilies([.accessoryCircular])
    }
}

struct Pro30DayComplication: Widget {
    let kind: String = "Pro30DayComplication"
    var body: some WidgetConfiguration {
        StaticConfiguration(kind: kind, provider: Provider()) { entry in
            GenericRectangularComplicationView(currentValue: entry.rollingAvg24h, dataArray: entry.dailyAverages30d, timeframeLabel: "30D")
                .containerBackground(.clear, for: .widget)
        }
        .configurationDisplayName("30-Day Averages")
        .description("[PRO] 30-day daily averages + 24-hour rolling average.")
        .supportedFamilies([.accessoryRectangular])
    }
}

struct Pro30DayGaugeComplication: Widget {
    let kind: String = "Pro30DayGaugeComplication"
    var body: some WidgetConfiguration {
        StaticConfiguration(kind: kind, provider: Provider()) { entry in
            GenericCircularComplicationView(currentValue: entry.rollingAvg24h, dataArray: entry.dailyAverages30d, timeframeLabel: "30D")
                .containerBackground(.clear, for: .widget)
        }
        .configurationDisplayName("30-Day Gauge")
        .description("[PRO] 30-day min/max range + 24-hour rolling average.")
        .supportedFamilies([.accessoryCircular])
    }
}
