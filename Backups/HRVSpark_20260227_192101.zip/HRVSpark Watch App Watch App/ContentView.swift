import SwiftUI
import WidgetKit

struct ContentView: View {
    @Environment(\.scenePhase) var scenePhase
    @State private var dataManager = HRVDataManager()
    
    // BETA AUTO-UNLOCK (TEMPORARY — remove before production paid launch)
    // Hardcoded true during beta; in production, relies solely on App Group value from iPhone StoreKitManager
    @State private var isProUnlocked: Bool = true
    
    // Design System
    let slateBlueTheme = LinearGradient(
        colors: [Color(red: 0.18, green: 0.22, blue: 0.30), Color.black],
        startPoint: .top,
        endPoint: .bottom
    )
    let cardTitleColor = Color.white.opacity(0.74)
    
    var body: some View {
        NavigationStack {
            ZStack {
                // Global Background
                slateBlueTheme
                    .ignoresSafeArea()
                
                if !dataManager.isAuthorized {
                    VStack {
                        Image(systemName: "heart.text.square")
                            .font(.largeTitle)
                            .foregroundColor(.white)
                            .padding(.bottom, 8)
                        Text("HRVSpark requires HealthKit access to display your data.")
                            .multilineTextAlignment(.center)
                            .padding()
                        Button("Authorize in Health App") {
                            dataManager.requestAuthorization { _ in }
                        }
                        .buttonStyle(.borderedProminent)
                        .tint(.blue)
                    }
                } else {
                    ScrollView {
                        VStack(spacing: 16) {
                            
                            // ---- CARD 1: FREE TIER (8 Hours) ----
                            VStack(alignment: .leading) {
                                Text("8H RAW + LATEST HRV")
                                    .font(.system(size: 13, weight: .bold))
                                    .foregroundColor(cardTitleColor)
                                
                                HStack(spacing: 8) {
                                    SparklineView(data: dataManager.sparklineData8Hours, maxContiguousGap: 12)
                                        .frame(maxWidth: .infinity, maxHeight: .infinity)
                                    
                                    VStack(alignment: .leading, spacing: 2) {
                                        HStack(spacing: 2) {
                                            Image(systemName: "triangle.fill")
                                                .font(.system(size: 8, weight: .bold))
                                                .rotationEffect(.degrees(-90))
                                            Text("8H")
                                                .font(.system(size: 10, weight: .bold, design: .monospaced))
                                        }
                                        .foregroundColor(.gray)
                                        
                                        Text("HRV")
                                            .font(.system(size: 10, weight: .bold))
                                            .foregroundColor(.gray)
                                        
                                        HStack(alignment: .lastTextBaseline, spacing: 0) {
                                            if let reading = dataManager.freeCardReading {
                                                Text("\(reading)")
                                                    .font(.system(.title3, design: .monospaced, weight: .bold))
                                                    .foregroundColor(.white)
                                                    .shadow(color: Color(red: 0.20, green: 0.55, blue: 1.0).opacity(1.0), radius: 4, x: 0, y: 0)
                                                    .shadow(color: Color(red: 0.20, green: 0.55, blue: 1.0).opacity(0.7), radius: 13, x: 0, y: 0)
                                                    .shadow(color: Color(red: 0.20, green: 0.55, blue: 1.0).opacity(0.5), radius: 23, x: 0, y: 0)
                                            } else {
                                                Text("--")
                                                    .font(.system(.title3, design: .monospaced, weight: .bold))
                                                    .foregroundColor(.white)
                                                    .shadow(color: Color(red: 0.20, green: 0.55, blue: 1.0).opacity(1.0), radius: 4, x: 0, y: 0)
                                                    .shadow(color: Color(red: 0.20, green: 0.55, blue: 1.0).opacity(0.7), radius: 13, x: 0, y: 0)
                                                    .shadow(color: Color(red: 0.20, green: 0.55, blue: 1.0).opacity(0.5), radius: 23, x: 0, y: 0)
                                            }
                                            Text("ms")
                                                .font(.system(.caption, design: .monospaced))
                                                .foregroundColor(.gray)
                                        }
                                    }
                                    .layoutPriority(1)
                                }
                                .frame(height: 60)
                                .padding(.top, 4)
                            }
                            .padding()
                            .background(Color.white.opacity(0.05))
                            .cornerRadius(12)
                            
                            Text("Every reading from the last 8 hours")
                                .font(.system(size: 9))
                                .foregroundColor(.gray.opacity(0.55))
                                .frame(maxWidth: .infinity, alignment: .leading)
                                .padding(.horizontal, 4)
                                .padding(.top, -8)
                            
                            Text("Dashed lines indicate periods when your device took no readings.")
                                .font(.system(size: 9))
                                .foregroundColor(.gray.opacity(0.4))
                                .frame(maxWidth: .infinity, alignment: .leading)
                                .padding(.horizontal, 4)
                                .padding(.top, -4)
                            
                            HStack(spacing: 4) {
                                Image(systemName: "iphone")
                                    .font(.system(size: 10))
                                Text("Last Sync:")
                                    .font(.system(size: 10))
                                if let syncDate = dataManager.lastCompanionContextSyncDate {
                                    Text(syncDate, style: .relative)
                                        .font(.system(size: 10, weight: .bold))
                                } else {
                                    Text("waiting")
                                        .font(.system(size: 10, weight: .bold))
                                }
                            }
                            .foregroundColor(.gray.opacity(0.85))
                            .frame(maxWidth: .infinity, alignment: .leading)
                            
                            // ---- PRO DIVIDER ----
                            if !isProUnlocked {
                                VStack(spacing: 4) {
                                    HStack {
                                        Image(systemName: "lock.fill")
                                        Text("Pro Complications")
                                            .font(.caption)
                                            .fontWeight(.bold)
                                    }
                                    Text("Unlock in the iPhone app")
                                        .font(.system(size: 9))
                                        .foregroundColor(.gray)
                                }
                                .frame(maxWidth: .infinity)
                                .padding()
                                .background(Color.blue.opacity(0.15))
                                .cornerRadius(12)
                            } else {
                                Divider().background(Color.gray.opacity(0.5))
                                
                                Text("PRO UNLOCKED")
                                    .font(.caption)
                                    .fontWeight(.bold)
                                    .foregroundColor(.green)
                                    .frame(maxWidth: .infinity, alignment: .center)
                                
                                // ---- CARD 2: PRO TIER (Hourly) ----
                                VStack(alignment: .leading) {
                                    Text("24H PER-HOUR AVG + 1H AVG")
                                        .font(.system(size: 13, weight: .bold))
                                        .foregroundColor(cardTitleColor)
                                    
                                    HStack(spacing: 8) {
                                        SparklineView(data: dataManager.hourlyAverages8Hours)
                                            .frame(maxWidth: .infinity, maxHeight: .infinity)
                                        
                                        VStack(alignment: .leading, spacing: 2) {
                                            HStack(spacing: 2) {
                                                Image(systemName: "triangle.fill")
                                                    .font(.system(size: 8, weight: .bold))
                                                    .rotationEffect(.degrees(-90))
                                                Text("24H")
                                                    .font(.system(size: 10, weight: .bold, design: .monospaced))
                                            }
                                            .foregroundColor(.gray)
                                            
                                            Text("HRV")
                                                .font(.system(size: 10, weight: .bold))
                                                .foregroundColor(.gray)
                                            
                                            HStack(alignment: .lastTextBaseline, spacing: 0) {
                                                if let reading = dataManager.proCard2Reading {
                                                    Text("\(reading)")
                                                        .font(.system(.title3, design: .monospaced, weight: .bold))
                                                        .foregroundColor(.white)
                                                        .shadow(color: Color(red: 0.20, green: 0.55, blue: 1.0).opacity(1.0), radius: 4, x: 0, y: 0)
                                                        .shadow(color: Color(red: 0.20, green: 0.55, blue: 1.0).opacity(0.7), radius: 13, x: 0, y: 0)
                                                        .shadow(color: Color(red: 0.20, green: 0.55, blue: 1.0).opacity(0.5), radius: 23, x: 0, y: 0)
                                                } else {
                                                    Text("--")
                                                        .font(.system(.title3, design: .monospaced, weight: .bold))
                                                        .foregroundColor(.white)
                                                        .shadow(color: Color(red: 0.20, green: 0.55, blue: 1.0).opacity(1.0), radius: 4, x: 0, y: 0)
                                                        .shadow(color: Color(red: 0.20, green: 0.55, blue: 1.0).opacity(0.7), radius: 13, x: 0, y: 0)
                                                        .shadow(color: Color(red: 0.20, green: 0.55, blue: 1.0).opacity(0.5), radius: 23, x: 0, y: 0)
                                                }
                                                Text("ms")
                                                    .font(.system(.caption, design: .monospaced))
                                                    .foregroundColor(.gray)
                                            }
                                        }
                                        .layoutPriority(1)
                                    }
                                    .frame(height: 60)
                                    .padding(.top, 4)
                                }
                                .padding()
                                .background(Color.white.opacity(0.05))
                                .cornerRadius(12)
                                
                                Text("Average per hour, last 24 hours")
                                    .font(.system(size: 9))
                                    .foregroundColor(.gray.opacity(0.55))
                                    .frame(maxWidth: .infinity, alignment: .leading)
                                    .padding(.horizontal, 4)
                                    .padding(.top, -8)
                                

                                
                                // ---- CARD 3: PRO TIER (7 Days) ----
                                VStack(alignment: .leading) {
                                    Text("7D PER-DAY AVG + 24H AVG")
                                        .font(.system(size: 13, weight: .bold))
                                        .foregroundColor(cardTitleColor)
                                    
                                    HStack(spacing: 8) {
                                        SparklineView(data: dataManager.dailyAverages7Days)
                                            .frame(maxWidth: .infinity, maxHeight: .infinity)
                                        
                                        VStack(alignment: .leading, spacing: 2) {
                                            HStack(spacing: 2) {
                                                Image(systemName: "triangle.fill")
                                                    .font(.system(size: 8, weight: .bold))
                                                    .rotationEffect(.degrees(-90))
                                                Text("7D")
                                                    .font(.system(size: 10, weight: .bold, design: .monospaced))
                                            }
                                            .foregroundColor(.gray)
                                            
                                            Text("HRV")
                                                .font(.system(size: 10, weight: .bold))
                                                .foregroundColor(.gray)
                                            
                                            HStack(alignment: .lastTextBaseline, spacing: 0) {
                                                if let reading = dataManager.proCard3Reading {
                                                    Text("\(reading)")
                                                        .font(.system(.title3, design: .monospaced, weight: .bold))
                                                        .foregroundColor(.white)
                                                        .shadow(color: Color(red: 0.20, green: 0.55, blue: 1.0).opacity(1.0), radius: 4, x: 0, y: 0)
                                                        .shadow(color: Color(red: 0.20, green: 0.55, blue: 1.0).opacity(0.7), radius: 13, x: 0, y: 0)
                                                        .shadow(color: Color(red: 0.20, green: 0.55, blue: 1.0).opacity(0.5), radius: 23, x: 0, y: 0)
                                                } else {
                                                    Text("--")
                                                        .font(.system(.title3, design: .monospaced, weight: .bold))
                                                        .foregroundColor(.white)
                                                        .shadow(color: Color(red: 0.20, green: 0.55, blue: 1.0).opacity(1.0), radius: 4, x: 0, y: 0)
                                                        .shadow(color: Color(red: 0.20, green: 0.55, blue: 1.0).opacity(0.7), radius: 13, x: 0, y: 0)
                                                        .shadow(color: Color(red: 0.20, green: 0.55, blue: 1.0).opacity(0.5), radius: 23, x: 0, y: 0)
                                                }
                                                Text("ms")
                                                    .font(.system(.caption, design: .monospaced))
                                                    .foregroundColor(.gray)
                                            }
                                        }
                                        .layoutPriority(1)
                                    }
                                    .frame(height: 60)
                                    .padding(.top, 4)
                                }
                                .padding()
                                .background(Color.white.opacity(0.05))
                                .cornerRadius(12)
                                
                                Text("Average per day, last 7 days")
                                    .font(.system(size: 9))
                                    .foregroundColor(.gray.opacity(0.55))
                                    .frame(maxWidth: .infinity, alignment: .leading)
                                    .padding(.horizontal, 4)
                                    .padding(.top, -8)
                                
                                // ---- CARD 4: PRO TIER (30 Days) ----
                                VStack(alignment: .leading) {
                                    let visible30dCount = dataManager.dailyAverages30Days.compactMap { $0 }.count
                                    
                                    HStack {
                                        Text("30D PER-DAY AVG + 24H AVG")
                                            .font(.system(size: 13, weight: .bold))
                                            .foregroundColor(cardTitleColor)
                                        
                                        Spacer()
                                        
                                        if visible30dCount < 28 {
                                            HStack(spacing: 2) {
                                                Image(systemName: "exclamationmark.circle")
                                                    .font(.system(size: 9))
                                                Text("Limited")
                                                    .font(.system(size: 9, weight: .bold))
                                            }
                                            .foregroundColor(.orange.opacity(0.85))
                                        }
                                    }
                                    
                                    HStack(spacing: 8) {
                                        SparklineView(data: dataManager.dailyAverages30Days)
                                            .frame(maxWidth: .infinity, maxHeight: .infinity)
                                        
                                        VStack(alignment: .leading, spacing: 2) {
                                            HStack(spacing: 2) {
                                                Image(systemName: "triangle.fill")
                                                    .font(.system(size: 8, weight: .bold))
                                                    .rotationEffect(.degrees(-90))
                                                Text("1M")
                                                    .font(.system(size: 10, weight: .bold, design: .monospaced))
                                            }
                                            .foregroundColor(.gray)
                                            
                                            Text("HRV")
                                                .font(.system(size: 10, weight: .bold))
                                                .foregroundColor(.gray)
                                            
                                            HStack(alignment: .lastTextBaseline, spacing: 0) {
                                                if let reading = dataManager.proCard3Reading {
                                                    Text("\(reading)")
                                                        .font(.system(.title3, design: .monospaced, weight: .bold))
                                                        .foregroundColor(.white)
                                                        .shadow(color: Color(red: 0.20, green: 0.55, blue: 1.0).opacity(1.0), radius: 4, x: 0, y: 0)
                                                        .shadow(color: Color(red: 0.20, green: 0.55, blue: 1.0).opacity(0.7), radius: 13, x: 0, y: 0)
                                                        .shadow(color: Color(red: 0.20, green: 0.55, blue: 1.0).opacity(0.5), radius: 23, x: 0, y: 0)
                                                } else {
                                                    Text("--")
                                                        .font(.system(.title3, design: .monospaced, weight: .bold))
                                                        .foregroundColor(.white)
                                                        .shadow(color: Color(red: 0.20, green: 0.55, blue: 1.0).opacity(1.0), radius: 4, x: 0, y: 0)
                                                        .shadow(color: Color(red: 0.20, green: 0.55, blue: 1.0).opacity(0.7), radius: 13, x: 0, y: 0)
                                                        .shadow(color: Color(red: 0.20, green: 0.55, blue: 1.0).opacity(0.5), radius: 23, x: 0, y: 0)
                                                }
                                                Text("ms")
                                                    .font(.system(.caption, design: .monospaced))
                                                    .foregroundColor(.gray)
                                            }
                                        }
                                        .layoutPriority(1)
                                    }
                                    .frame(height: 60)
                                    .padding(.top, 4)
                                    
                                    if visible30dCount < 28 {
                                        Text("Showing ~\(visible30dCount) days from watch-local history.")
                                            .font(.system(size: 8))
                                            .foregroundColor(.gray.opacity(0.85))
                                            .padding(.top, 2)
                                    }
                                }
                                .padding()
                                .background(Color.white.opacity(0.05))
                                .cornerRadius(12)
                                
                                Text("Average per day, last 30 days")
                                    .font(.system(size: 9))
                                    .foregroundColor(.gray.opacity(0.55))
                                    .frame(maxWidth: .infinity, alignment: .leading)
                                    .padding(.horizontal, 4)
                                    .padding(.top, -8)
                            }
                            
                            // ---- ABOUT BUTTON ----
                            NavigationLink(destination: AboutView()) {
                                HStack {
                                    Image(systemName: "info.circle")
                                    Text("About HRV & Apple Watch")
                                }
                                .font(.footnote)
                                .foregroundColor(.gray)
                                .padding(.top, 16)
                            }
                            .buttonStyle(.plain)
                            
                        }
                        .padding()
                    }
                    // MANUAL SYNC (Pull to refresh)
                    .refreshable {
                        dataManager.fetchAllData()
                        WidgetCenter.shared.reloadAllTimelines()
                    }
                }
            }
        }
        // INITIAL LOAD
        .onAppear {
            dataManager.requestAuthorization { _ in }
        }
        // BACKGROUND RESUME (The v1 bug fix!)
        .onChange(of: scenePhase) { oldPhase, newPhase in
            if newPhase == .active {
                // BETA AUTO-UNLOCK (TEMPORARY — remove before production paid launch)
                // In production, restore: let defaults = UserDefaults(suiteName: "group.com.filamentlabs.HRVSpark")
                //                         isProUnlocked = defaults?.bool(forKey: "isProUnlocked") ?? false
                isProUnlocked = true
                
                if dataManager.isAuthorized {
                    dataManager.fetchAllData()
                    WidgetCenter.shared.reloadAllTimelines()
                }
            }
        }
    }
}

// MARK: - Graph Components




// MARK: - About Page

struct AboutView: View {
    // Re-use theme for consistency
    let slateBlueTheme = LinearGradient(
        colors: [Color(red: 0.18, green: 0.22, blue: 0.30), Color.black],
        startPoint: .top,
        endPoint: .bottom
    )
    
    var body: some View {
        ZStack {
            slateBlueTheme.ignoresSafeArea()
            
            ScrollView {
                VStack(alignment: .leading, spacing: 20) {
                    Text("How It Works")
                        .font(.headline)
                        .foregroundColor(.white)
                    
                    Text("HRVSpark reads data directly from Apple Health. It performs no diagnosis or algorithmic interpretation—it simply visualizes your raw SDNN measurements.")
                        .font(.body)
                        .foregroundColor(.gray)
                    
                    Text("The Mindfulness Workaround")
                        .font(.headline)
                        .foregroundColor(.white)
                        .padding(.top, 10)
                    
                    Text("watchOS restricts how often apps can measure HRV in the background to save battery.\n\nTo force a new, immediate reading at any time, run a 1-Minute 'Breathe' session in the native Apple Mindfulness app. HRVSpark (and its complications) will automatically detect the new reading within minutes.")
                        .font(.body)
                        .foregroundColor(.gray)
                    
                    Divider()
                        .background(Color.white.opacity(0.3))
                        .padding(.vertical, 4)
                    
                    Text("Watch History Limits")
                        .font(.headline)
                        .foregroundColor(.white)
                    
                    Text("The watch can show a shorter local HRV history than your iPhone. When your iPhone is reachable, complications can use iPhone-computed long-term data.")
                        .font(.body)
                        .foregroundColor(.gray)
                    
                    Spacer(minLength: 40)
                }
                .padding()
            }
        }
        .navigationTitle("About")
        .navigationBarTitleDisplayMode(.inline)
    }
}

#Preview {
    ContentView()
}
