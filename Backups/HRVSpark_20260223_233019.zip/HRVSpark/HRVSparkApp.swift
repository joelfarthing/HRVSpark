//
//  HRVSparkApp.swift
//  HRVSpark
//
//  Created by Joel Farthing on 2/22/26.
//

import SwiftUI

@main
struct HRVSparkApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
