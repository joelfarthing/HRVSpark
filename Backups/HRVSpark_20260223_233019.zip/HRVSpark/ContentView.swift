import SwiftUI
import StoreKit

struct ContentView: View {
    @State private var dataManager = iOSDataManager()
    
    // Theme Colors
    let slateBlueTheme = LinearGradient(
        colors: [Color(red: 0.18, green: 0.22, blue: 0.30), Color.black],
        startPoint: .top,
        endPoint: .bottom
    )
    
    // StoreKit Pro unlock
    @StateObject private var storeKit = StoreKitManager.shared
    
    private let cardGraphTitleFont = Font.system(size: 16, weight: .bold)
    private let cardTitleColor = Color.white.opacity(0.74)
    
    var body: some View {
        if !dataManager.isAuthorized {
            authorizationView
        } else {
            TabView {
                dashboardTab
                    .tabItem {
                        Label("Dashboard", systemImage: "waveform.path.ecg")
                    }
                
                engineTab
                    .tabItem {
                        Label("Engine", systemImage: "bolt.heart.fill")
                    }
                
                infoTab
                    .tabItem {
                        Label("Info", systemImage: "info.circle.fill")
                    }
            }
            .tint(.white) // Tab bar selection color
            .onAppear {
                // Ensure tab bar is somewhat translucent over the dark background
                let appearance = UITabBarAppearance()
                appearance.configureWithOpaqueBackground()
                appearance.backgroundColor = UIColor(white: 0.1, alpha: 1.0)
                UITabBar.appearance().standardAppearance = appearance
                UITabBar.appearance().scrollEdgeAppearance = appearance
            }
        }
    }
    
    private var brandHeaderReservedSpace: some View {
        Image("HRVSparkWordmark")
            .resizable()
            .scaledToFit()
            .frame(maxWidth: .infinity)
            .padding(.top, 20) // Normal top spacing, not touching the island
    }
    
    // MARK: - 1. Authorization Screen
    var authorizationView: some View {
        ZStack {
            slateBlueTheme.ignoresSafeArea()
            VStack {
                Image(systemName: "heart.text.square")
                    .font(.system(size: 60))
                    .foregroundColor(.white)
                    .padding(.bottom, 16)
                Text("Welcome to HRVSpark")
                    .font(.title)
                    .bold()
                    .foregroundColor(.white)
                    .padding(.bottom, 4)
                Text("HRVSpark requires HealthKit access to serve data to your Apple Watch.")
                    .multilineTextAlignment(.center)
                    .foregroundColor(.gray)
                    .padding(.horizontal, 32)
                    .padding(.bottom, 24)
                
                Button(action: {
                    dataManager.requestAuthorization { _ in }
                }) {
                    Text("Authorize in Health App")
                        .font(.headline)
                        .foregroundColor(.white)
                        .padding()
                        .frame(maxWidth: .infinity)
                        .background(Color.blue)
                        .cornerRadius(12)
                }
                .padding(.horizontal, 32)
            }
        }
        .onAppear {
            dataManager.requestAuthorization { _ in }
        }
    }
    
    // MARK: - 2. Dashboard Tab
    var dashboardTab: some View {
        NavigationStack {
            ZStack {
                slateBlueTheme.ignoresSafeArea()
                
                ScrollView {
                    VStack(spacing: 0) {
                        brandHeaderReservedSpace
                        
                        VStack(spacing: 16) {
                            // ---- CARD 1: FREE TIER (8 Hours) ----
                            VStack(alignment: .leading) {
                                VStack(alignment: .leading, spacing: 4) {
                                    Text("LATEST HRV:")
                                        .font(.subheadline)
                                        .fontWeight(.bold)
                                        .foregroundColor(.gray)
                                    
                                    HStack(alignment: .lastTextBaseline, spacing: 0) {
                                        if let reading = dataManager.freeCardReading {
                                            Text("\(reading)")
                                                .font(.system(.largeTitle, design: .monospaced, weight: .bold))
                                                .foregroundColor(.white)
                                                .shadow(color: Color(red: 0.20, green: 0.55, blue: 1.0).opacity(1.0), radius: 4, x: 0, y: 0)
                                                .shadow(color: Color(red: 0.20, green: 0.55, blue: 1.0).opacity(0.7), radius: 13, x: 0, y: 0)
                                                .shadow(color: Color(red: 0.20, green: 0.55, blue: 1.0).opacity(0.5), radius: 23, x: 0, y: 0)
                                        } else {
                                            Text("--")
                                                .font(.system(.largeTitle, design: .monospaced, weight: .bold))
                                                .foregroundColor(.white)
                                                .shadow(color: Color(red: 0.20, green: 0.55, blue: 1.0).opacity(1.0), radius: 4, x: 0, y: 0)
                                                .shadow(color: Color(red: 0.20, green: 0.55, blue: 1.0).opacity(0.7), radius: 13, x: 0, y: 0)
                                                .shadow(color: Color(red: 0.20, green: 0.55, blue: 1.0).opacity(0.5), radius: 23, x: 0, y: 0)
                                        }
                                        Text("ms")
                                            .font(.system(.body, design: .monospaced))
                                            .foregroundColor(.gray)
                                            .padding(.leading, 4)
                                    }
                                }
                                
                                Text("LAST 8 HOURS")
                                    .font(cardGraphTitleFont)
                                    .foregroundColor(cardTitleColor)
                                    .padding(.top, 8)
                                
                                SparklineView(data: dataManager.sparklineData8Hours, maxContiguousGap: 12)
                                    .frame(height: 100)
                                    .padding(.top, 8)
                            }
                            .padding()
                            .background(Color.white.opacity(0.05))
                            .cornerRadius(16)
                            
                            // ---- PRO DIVIDER ----
                            if !storeKit.isProUnlocked {
                                Button(action: {
                                    Task {
                                        try? await storeKit.purchase()
                                    }
                                }) {
                                    HStack {
                                        Image(systemName: "lock.fill")
                                        if let product = storeKit.proProduct {
                                            Text("Unlock Pro — \(product.displayPrice)")
                                                .font(.subheadline)
                                                .fontWeight(.bold)
                                        } else {
                                            Text("Unlock Pro Complications")
                                                .font(.subheadline)
                                                .fontWeight(.bold)
                                        }
                                    }
                                    .frame(maxWidth: .infinity)
                                    .padding()
                                    .background(Color.blue.opacity(0.3))
                                    .cornerRadius(12)
                                }
                                .buttonStyle(.plain)
                                .disabled(storeKit.purchaseInProgress)
                                
                                Button(action: {
                                    Task { await storeKit.restore() }
                                }) {
                                    Text("Restore Purchases")
                                        .font(.caption)
                                        .foregroundColor(.gray)
                                }
                                .buttonStyle(.plain)
                                .padding(.top, 4)
                            } else {
                                Divider().background(Color.gray.opacity(0.5)).padding(.vertical, 8)
                                
                                Text("PRO UNLOCKED")
                                    .font(.subheadline)
                                    .fontWeight(.bold)
                                    .foregroundColor(.green)
                                    .frame(maxWidth: .infinity, alignment: .center)
                                
                                // ---- CARD 2: PRO TIER (Hourly) ----
                                VStack(alignment: .leading) {
                                    Text("LAST 8 HOURS (HOURLY AVG)")
                                        .font(cardGraphTitleFont)
                                        .foregroundColor(cardTitleColor)
                                    
                                    HStack(alignment: .lastTextBaseline, spacing: 0) {
                                        if let reading = dataManager.proCard2Reading {
                                            Text("\(reading)")
                                                .font(.system(.largeTitle, design: .monospaced, weight: .bold))
                                                .foregroundColor(.white)
                                                .shadow(color: Color(red: 0.20, green: 0.55, blue: 1.0).opacity(1.0), radius: 4, x: 0, y: 0)
                                                .shadow(color: Color(red: 0.20, green: 0.55, blue: 1.0).opacity(0.7), radius: 13, x: 0, y: 0)
                                                .shadow(color: Color(red: 0.20, green: 0.55, blue: 1.0).opacity(0.5), radius: 23, x: 0, y: 0)
                                        } else {
                                            Text("--")
                                                .font(.system(.largeTitle, design: .monospaced, weight: .bold))
                                                .foregroundColor(.white)
                                                .shadow(color: Color(red: 0.20, green: 0.55, blue: 1.0).opacity(1.0), radius: 4, x: 0, y: 0)
                                                .shadow(color: Color(red: 0.20, green: 0.55, blue: 1.0).opacity(0.7), radius: 13, x: 0, y: 0)
                                                .shadow(color: Color(red: 0.20, green: 0.55, blue: 1.0).opacity(0.5), radius: 23, x: 0, y: 0)
                                        }
                                        Text("ms")
                                            .font(.system(.body, design: .monospaced))
                                            .foregroundColor(.gray)
                                            .padding(.leading, 4)
                                    }
                                    
                                    SparklineView(data: dataManager.hourlyAverages8Hours)
                                        .frame(height: 100)
                                        .padding(.top, 8)
                                }
                                .padding()
                                .background(Color.white.opacity(0.05))
                                .cornerRadius(16)
                                
                                if let rollingAvg = dataManager.proCard3Reading {
                                    HStack(spacing: 0) {
                                        Text("Rolling 24hr Avg: ")
                                            .font(.system(size: 14, weight: .bold))
                                            .foregroundColor(.gray)
                                        Text("\(rollingAvg)ms")
                                            .font(.system(.headline, design: .monospaced, weight: .bold))
                                            .foregroundColor(.white)
                                    }
                                    .padding(.vertical, 8)
                                }
                                
                                // ---- CARD 3: PRO TIER (7 Days) ----
                                VStack(alignment: .leading) {
                                    Text("LAST 7 DAYS (DAILY AVG)")
                                        .font(cardGraphTitleFont)
                                        .foregroundColor(cardTitleColor)
                                    
                                    SparklineView(data: dataManager.dailyAverages7Days)
                                        .frame(height: 100)
                                        .padding(.top, 8)
                                }
                                .padding()
                                .background(Color.white.opacity(0.05))
                                .cornerRadius(16)
                                
                                // ---- CARD 4: PRO TIER (30 Days) ----
                                VStack(alignment: .leading) {
                                    Text("LAST 30 DAYS (DAILY AVG)")
                                        .font(cardGraphTitleFont)
                                        .foregroundColor(cardTitleColor)
                                    
                                    SparklineView(data: dataManager.dailyAverages30Days)
                                        .frame(height: 100)
                                        .padding(.top, 8)
                                }
                                .padding()
                                .background(Color.white.opacity(0.05))
                                .cornerRadius(16)
                            }
                        }
                        .padding()
                    }
                }
                .refreshable {
                    dataManager.fetchAllData()
                }
            }
            .navigationTitle("")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar(.hidden, for: .navigationBar)
        }
    }
    
    // MARK: - 3. Engine Tab (Original View)
    var engineTab: some View {
        NavigationStack {
            ZStack {
                slateBlueTheme.ignoresSafeArea()
                
                ScrollView {
                    VStack(spacing: 24) {
                        brandHeaderReservedSpace
                        
                        // App Header
                        VStack(spacing: 8) {
                            Image(systemName: "bolt.heart.fill")
                                .font(.system(size: 60))
                                .foregroundColor(.white)
                            Text("HRVSpark Engine")
                                .font(.title)
                                .bold()
                                .foregroundColor(.white)
                            Text("Your iPhone is currently processing data requests from your Apple Watch Complications.")
                                .font(.subheadline)
                                .foregroundColor(.gray)
                                .multilineTextAlignment(.center)
                                .padding(.horizontal)
                        }
                        .padding(.top, 8)
                        
                        // Status Card
                        VStack(alignment: .leading, spacing: 16) {
                            HStack {
                                Text("ENGINE STATUS")
                                    .font(.subheadline)
                                    .fontWeight(.bold)
                                    .foregroundColor(.gray)
                                Spacer()
                                HStack(spacing: 4) {
                                    Circle()
                                        .fill(Color.green)
                                        .frame(width: 8, height: 8)
                                    Text("Active")
                                        .font(.subheadline)
                                        .foregroundColor(.green)
                                        .bold()
                                }
                            }
                            
                            Divider().background(Color.white.opacity(0.2))
                            
                            HStack {
                                Text("HealthKit Access")
                                    .foregroundColor(.white)
                                Spacer()
                                Image(systemName: "checkmark.circle.fill")
                                    .foregroundColor(.green)
                            }
                            
                            HStack {
                                Text("Apple Watch Paired")
                                    .foregroundColor(.white)
                                Spacer()
                                Image(systemName: "applewatch")
                                    .foregroundColor(.gray)
                            }
                            
                            HStack {
                                Text("Last sync to watch")
                                    .foregroundColor(.white)
                                Spacer()
                                if let publishedAt = dataManager.lastCompanionContextPublishDate {
                                    Text(publishedAt, style: .relative)
                                        .font(.system(.caption, design: .monospaced, weight: .bold))
                                        .foregroundColor(.green)
                                } else {
                                    Text("Waiting")
                                        .font(.system(.caption, design: .monospaced, weight: .bold))
                                        .foregroundColor(.orange)
                                }
                            }
                        }
                        .padding()
                        .background(Color.white.opacity(0.05))
                        .cornerRadius(16)
                        .padding(.horizontal)
                        
                        // Info Card
                        VStack(alignment: .leading, spacing: 12) {
                            Text("HOW OFF-LOADING WORKS")
                                .font(.subheadline)
                                .fontWeight(.bold)
                                .foregroundColor(.gray)
                            
                            Text("To preserve the battery life and memory of your wearable, HRVSpark uses your iPhone to calculate massive historical data aggregations (like the 30-Day Pro metrics).")
                                .font(.subheadline)
                                .foregroundColor(.white)
                            
                            Text("Keep this app installed so your complications can seamlessly request data updates in the background.")
                                .font(.subheadline)
                                .foregroundColor(.gray)
                        }
                        .padding()
                        .background(Color.white.opacity(0.05))
                        .cornerRadius(16)
                        .padding(.horizontal)
                        
                        Spacer(minLength: 40)
                    }
                }
            }
            .navigationTitle("")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar(.hidden, for: .navigationBar)
        }
    }
    
    // MARK: - 4. Info & Workaround Tab
    var infoTab: some View {
        NavigationStack {
            ZStack {
                slateBlueTheme.ignoresSafeArea()
                
                ScrollView {
                    VStack(alignment: .leading, spacing: 0) {
                        brandHeaderReservedSpace
                        
                        VStack(alignment: .leading, spacing: 24) {
                            VStack(alignment: .leading, spacing: 12) {
                                Text("How It Works")
                                    .font(.title3)
                                    .fontWeight(.bold)
                                    .foregroundColor(.white)
                                
                                Text("HRVSpark reads data directly from Apple Health. It performs no diagnosis or algorithmic interpretation—it simply visualizes your raw SDNN measurements.")
                                    .font(.body)
                                    .foregroundColor(.gray)
                            }
                            .padding()
                            .background(Color.white.opacity(0.05))
                            .cornerRadius(16)
                            
                            VStack(alignment: .leading, spacing: 12) {
                                HStack {
                                    Image(systemName: "lungs.fill")
                                        .foregroundColor(.teal)
                                        .font(.title2)
                                    Text("The Mindfulness Workaround")
                                        .font(.title3)
                                        .fontWeight(.bold)
                                        .foregroundColor(.white)
                                }
                                
                                Text("watchOS restricts how often apps can measure HRV in the background to save battery.")
                                    .font(.body)
                                    .foregroundColor(.white)
                                
                                Text("To force a new, immediate reading at any time, run a 1-Minute 'Breathe' session in the native Apple Mindfulness app. HRVSpark (and its complications) will automatically detect the new reading within minutes.")
                                    .font(.body)
                                    .foregroundColor(.gray)
                            }
                            .padding()
                            .background(Color.white.opacity(0.05))
                            .cornerRadius(16)
                            
                            VStack(alignment: .leading, spacing: 12) {
                                HStack {
                                    Image(systemName: "applewatch")
                                        .foregroundColor(.blue)
                                        .font(.title2)
                                    Text("Watch History Window")
                                        .font(.title3)
                                        .fontWeight(.bold)
                                        .foregroundColor(.white)
                                }
                                
                                Text("Your watch may retain a shorter local HRV history than your iPhone.")
                                    .font(.body)
                                    .foregroundColor(.white)
                                
                                Text("Complications perform best when your iPhone is reachable, because long-term aggregates can be off-loaded to the companion app.")
                                    .font(.body)
                                    .foregroundColor(.gray)
                            }
                            .padding()
                            .background(Color.white.opacity(0.05))
                            .cornerRadius(16)
                            
                            Spacer(minLength: 40)
                        }
                        .padding()
                    }
                }
            }
            .navigationTitle("")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar(.hidden, for: .navigationBar)
        }
    }
}

#Preview {
    ContentView()
}
